//
//  ViewController.swift
//  DataPassingTable
//
//  Created by Mac on 4/12/18.
//  Copyright © 2018 agile. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var txtID: UITextField!
    @IBOutlet var txtPass: UITextField!
    @IBOutlet var txtDepartment: UITextField!
    @IBOutlet var txtCompanyName: UITextField!
    
    var aryData = [Any]()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationController?.navigationBar.setBackgroundImage(UIImage(), for: .default)
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }

    @IBAction func PressLogin(_ sender: UIButton)
    {
        let dicData:NSMutableDictionary = [:]
        
        dicData.setValue(txtID.text, forKey: "ID")
        dicData.setValue(txtPass.text, forKey: "Password")
       
        
        aryData.append(dicData)
    }
    
    @IBAction func PressShow(_ sender: UIButton)
    {
        let Controller = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "SecondViewController")as? SecondViewController
 
        
    Controller?.aryData = aryData
        
        
        navigationController?.pushViewController(Controller!, animated: true)
    }
    
    @IBAction func GotoBlock(_ sender: UIButton)
    {
        let Controller1 = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "GotoBlockViewController")as? GotoBlockViewController
        
        navigationController?.pushViewController(Controller1!, animated: true)
    }
    
    
}

