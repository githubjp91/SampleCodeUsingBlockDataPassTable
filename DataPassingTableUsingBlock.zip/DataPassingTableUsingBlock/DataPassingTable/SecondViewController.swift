//
//  SecondViewController.swift
//  DataPassingTable
//
//  Created by Mac on 4/12/18.
//  Copyright © 2018 agile. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController, UITableViewDelegate,UITableViewDataSource {
  
   
    @IBOutlet var tbtView: UITableView!
    

    var aryData = [Any]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
 
        
        
        tbtView.register(UINib(nibName: "customTableViewCell", bundle :nil), forCellReuseIdentifier: "customTableViewCell")
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
       
    }
    

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return aryData.count
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 70
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
       
    let cell = tableView.dequeueReusableCell(withIdentifier: "customTableViewCell") as! customTableViewCell
        
        cell.lblID.text = "USER_ID: \((aryData[indexPath.row]as! NSDictionary).value(forKey: "ID") as! String)"
        
        cell.lblPass.text = "PASSWORD: \((aryData[indexPath.row]as! NSDictionary).value(forKey: "Password")as! String)"
        
        
        
        
        //cell.lblName.text = "Name: \((arrData[indexPath.row] as! NSDictionary).value(forKey: "Name") as! String )"
        
        
        return cell
    }
}
