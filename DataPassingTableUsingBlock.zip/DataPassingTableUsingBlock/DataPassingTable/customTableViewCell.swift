//
//  customTableViewCell.swift
//  DataPassingTable
//
//  Created by Mac on 4/12/18.
//  Copyright © 2018 agile. All rights reserved.
//

import UIKit

class customTableViewCell: UITableViewCell {
    
    @IBOutlet var cellBackView: UIView!
    
    @IBOutlet var lblPass: UILabel!
    @IBOutlet var lblID: UILabel!
   
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        cellBackView.layer.cornerRadius = 15
        cellBackView.layer.borderWidth = 1.0
        cellBackView.layer.borderColor = UIColor.green.cgColor
        cellBackView.layer.backgroundColor = UIColor.darkGray.cgColor
        
        
        
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
